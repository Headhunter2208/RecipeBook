//
//  Recipes+CoreDataClass.swift
//  CacheRecipes
//
//  Created by Jason Head on 12/2/23.
//
//

import Foundation
import CoreData

@objc(Recipes)
public class Recipes: NSManagedObject {

}
