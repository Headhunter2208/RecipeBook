//
//  Recipes+CoreDataProperties.swift
//  CacheRecipes
//
//  Created by Jason Head on 12/2/23.
//
//

import Foundation
import CoreData


extension Recipes {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Recipes> {
        return NSFetchRequest<Recipes>(entityName: "Recipes")
    }

    @NSManaged public var recipe: String?
    @NSManaged public var steps: String?

}

extension Recipes : Identifiable {

}
