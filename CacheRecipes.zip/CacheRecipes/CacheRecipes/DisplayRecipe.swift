//
//  DisplayRecipe.swift
//  CacheRecipes
//
//  Created by Jason Head on 12/3/23.
//

import UIKit

class DisplayRecipe: UIViewController {
    
    //Elements that advance and retract and show steps
    let label = UILabel()
    let nextButton = UIButton()
    let lastButton = UIButton()
    var increment : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        label.text = "123"
        
        readRecipe(ChocChipCookies, increment: increment)
    }

    
    func readRecipe(_ name : [String], increment : Int) {
        view.addSubview(label)
        view.addSubview(nextButton)
        view.addSubview(lastButton)
        
        label.text = name[increment]
        
        self.increment = increment + 1
        
        label.font = UIFont.systemFont(ofSize: 24)
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 5
        label.textAlignment = .center

        
        nextButton.configuration = .filled()
        nextButton.configuration?.baseBackgroundColor = .systemIndigo
        nextButton.configuration?.title = "Next Step"
        nextButton.addTarget(self, action: #selector(AdvanceSteps), for: .touchUpInside)
        
        lastButton.configuration = .filled()
        lastButton.configuration?.baseBackgroundColor = .systemIndigo
        lastButton.configuration?.title = "Last Step"
        lastButton.addTarget(self, action: #selector(RetractSteps), for: .touchUpInside)
        
        //Constraints to format the text and buttons properly
        NSLayoutConstraint.activate([
        label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        label.widthAnchor.constraint(equalTo: view.widthAnchor),
        
        lastButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
        lastButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
        lastButton.widthAnchor.constraint(equalToConstant: 150),
        lastButton.heightAnchor.constraint(equalToConstant: 50),
        
        nextButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
        nextButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
        nextButton.widthAnchor.constraint(equalToConstant: 150),
        nextButton.heightAnchor.constraint(equalToConstant: 50),
        
        ])
        
        label.translatesAutoresizingMaskIntoConstraints = false
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        lastButton.translatesAutoresizingMaskIntoConstraints = false
        
    }
    
    @objc func AdvanceSteps(){
        label.text = ChocChipCookies[increment]
        let last = ChocChipCookies.last
        
        if(ChocChipCookies[increment] == last) {
            nextButton.isUserInteractionEnabled = false
        }
        
        else {
            increment += 1
            nextButton.isUserInteractionEnabled = true
        }
    }
    
    @objc func RetractSteps(){
        if(increment == 0) {
            lastButton.isUserInteractionEnabled = false
        }
        
        else {
            lastButton.isUserInteractionEnabled = true
            increment -= 1
            label.text = ChocChipCookies[increment]
        }
    }
    
    var ChocChipCookies: [String] = ["Preheat Oven to 375°", "Combine 2 1/4 cups flour, 1 tsp baking soda and 1 tsp salt in small bowl. Set aside",
                           "Beat 1 cup (2 sticks) butter, 3/4 cup granulated sugar, 3/4 cup brown sugar and 1 tsp vanilla with stand mixer",
                           "Beat in 2 eggs, one at a time, beating well after each addition", "Gradually beat in flour mixture",
                           "Remove from stand mixer and mix in chocolate chips by hand", "scoop onto baking sheet, bake for 9-11 minutes, once done let cool"]
    
}
