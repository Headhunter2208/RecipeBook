//
//  FirstScreen.swift
//  CacheRecipes
//
//  Created by Jason Head on 12/2/23.
//

import UIKit
import CoreData

class FirstScreen: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    let tableView: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return table
    }()
    
    private var AllRecipes = [Recipes]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Recipe Cache"
        navigationController?.navigationBar.prefersLargeTitles = true
        
        view.addSubview(tableView)
        getAllRecipes()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.frame = view.bounds
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(didTapAdd))
        
        }
        
    
    @objc private func didTapAdd() {
        let alert = UIAlertController(title: "Recipe Adder", message: "Enter new recipe title", preferredStyle: .alert)
        
        
        //Calls to create buttons for UI
        //setupButton()
        
        alert.addTextField(configurationHandler: nil)
        alert.addAction(UIAlertAction(title: "Enter", style: .cancel, handler:  { _ in
            guard let field  = alert.textFields?.first, let text = field.text, !text.isEmpty else {
                return
            }
            self.createRecipe(name: text)
        }))
        
        present(alert, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AllRecipes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let AllRecipes = AllRecipes[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = AllRecipes.recipe
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = AllRecipes[indexPath.row]
        let sheet = UIAlertController(title: "What would you like to do?", message:  nil, preferredStyle: .actionSheet)
        
        sheet.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: {[weak self] _ in
            self?.deleteRecipe(item: item)
            self?.getAllRecipes()
        }))
        
        sheet.addAction(UIAlertAction(title: "Make", style: .default, handler: { _ in
            self.LaunchNewWindow()
        }))
        
        present(sheet, animated: true)
    }
    
    func LaunchNewWindow() {
        let nextScreen = DisplayRecipe()
        nextScreen.title = "Directions"
        navigationController?.pushViewController(nextScreen, animated: true)
    }
    
    //CORE DATA FUNCTIONS
    
    func getAllRecipes() {
        do {
            AllRecipes = try context.fetch(Recipes.fetchRequest())
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        catch {
            //error handling goes here
        }
    }
    
    func createRecipe(name: String) {
        let newItem = Recipes(context: context)
        newItem.recipe = name
        
        do {
            try context.save()
            getAllRecipes()
        }
        catch {
            
        }
    }
    
    func deleteRecipe(item : Recipes) {
        context.delete(item)
        
        do {
            try context.save()
        }
        catch {
            //error handling
        }
    }
    
    func updateItem(item : Recipes, name: String) {
        item.recipe = name
        
        do {
            try context.save()
        }
        catch {
            //error handling
        }

    }
    
  /*  func setupButton() {
        view.backgroundColor = .systemMint
        view.addSubview(DessertRecipeButton)
        view.addSubview(DinnerRecipeButton)
        
        DinnerRecipeButton.configuration = .filled()
        DinnerRecipeButton.configuration?.baseBackgroundColor = .systemIndigo
        DinnerRecipeButton.configuration?.title = "Dinner Recipes"
        
        DessertRecipeButton.configuration = .filled()
        DessertRecipeButton.configuration?.baseBackgroundColor = .systemIndigo
        DessertRecipeButton.configuration?.title = "Dessert Recipes"
        
        //Activates constraints automatically
        NSLayoutConstraint.activate([
            DinnerRecipeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            DinnerRecipeButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            DinnerRecipeButton.widthAnchor.constraint(equalToConstant: 150),
            DinnerRecipeButton.heightAnchor.constraint(equalToConstant: 50),
            
            DessertRecipeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            DessertRecipeButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            DessertRecipeButton.widthAnchor.constraint(equalToConstant: 150),
            DessertRecipeButton.heightAnchor.constraint(equalToConstant: 50),
            
        ])
        
        //Necessary for all UI elements
        DinnerRecipeButton.translatesAutoresizingMaskIntoConstraints = false
        DessertRecipeButton.translatesAutoresizingMaskIntoConstraints = false
    } */
}

